package com.servicemate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.servicemate.entity.User;
import com.servicemate.service.UserService;

@RestController
@RequestMapping("/api/auth")

// Allow requests from React frontend
@CrossOrigin(origins = "http://localhost:5173")

public class AuthController {

    @Autowired
    private UserService service;

    // Signup API
    @PostMapping("/signup")
    public User register(@RequestBody User user){
        return service.register(user);
    }

    // Login API
    @PostMapping("/login")
    public User login(@RequestBody User user){
        return service.login(user.getEmail(), user.getPassword());
    }
}