package com.servicemate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.servicemate.entity.User;

public interface UserRepository extends JpaRepository<User,Long>{

    User findByEmail(String email);

}